# Mao Practice Skill Implementation Plan

> For agentic workers: use skill-creator, writing-skills, meaningful behavioral scenarios and the tested standard-library release builder.

**Goal:** 交付可公开安装的中文毛选方法 Skill。
**Architecture:** `mao-practice` 与按需参考资料；JSON 配置生成独立安装包及完整指令。
**Tech Stack:** Markdown、YAML、JSON、Python 3.10+ 标准库。
**Spec:** [design.md](design.md)

- [x] 实际打开并核实五篇原文，写精选来源和现代应用边界。
- [x] 编写 Skill、方法、模板、虚构示例和说明。
- [x] 复用构建器，配置独立项目与参考路径，运行格式和分发测试。
- [x] 独立行为试答：无事实时的矛盾候选、反例改变判断、对原文的归因、行动与复盘。
- [x] 整体审查和修复，准备独立包及现有公开仓库的发布、核验流程。

Review focus: 原文与编写者推导的区分、矛盾概念的准确性、是否武断归因或对人贴标签、个人信息与外部行动边界、分发路径完整性。
